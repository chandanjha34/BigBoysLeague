import React from 'react'
import AboutBigs from '../../assets/Home_assets/image1.png'

function AboutBig(){
  return (
    <div>
        <div>About Big boys league</div>
        <div>Where passion meets profession in a series of thrilling championships!</div>
        <div>One7 presents The One7 BigBoys T20 Cricket League for passionate corporate cricketers. We at One7 Sports are excited to bring to you an experience you would cherish for a lifetime. Our main objective is to encourage participation of working professionals who have the passion and love for this celebrated game of Cricket. This tournament is a platform for cricket enthusiasts who play this game for fun-n-fitness alongside their full-time profession.We have successfully concluded season 1 of BBL and now are happy and excited to launch the season 2 for BBL making this tournament a series of championships. Season 1 was widely appreciated and enjoyed by
        more than 200 corporate cricketers playing from 10 teams owned by corporate individuals as franchisees of One7 BigBoys League. Stay tuned and visit the page of BBL Season 2 here to know more about what’s coming.</div>
        <div><img src={AboutBigs} alt="" /></div>
    </div>
  );
}
export default AboutBig;
